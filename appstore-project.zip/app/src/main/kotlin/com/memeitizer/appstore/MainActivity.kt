package com.memeitizer.appstore

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import coil.compose.rememberAsyncImagePainter
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import android.widget.Toast
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.res.painterResource

// ---------- Data model ----------
data class AppItem(
    @SerializedName("id") val id: String,
    @SerializedName("name") val name: String,
    @SerializedName("icon") val icon: String,
    @SerializedName("description") val description: String,
    @SerializedName("category") val category: String,
    @SerializedName("developer") val developer: String,
    @SerializedName("rating") val rating: Double,
    @SerializedName("price") val price: String
)

// ---------- Retrofit ----------
interface AppApi {
    @GET("appstore/apps/list.json")
    suspend fun getApps(): List<AppItem>
}
val retrofit = Retrofit.Builder()
    .baseUrl("https://memeitizer.com/")
    .addConverterFactory(GsonConverterFactory.create())
    .client(OkHttpClient.Builder().build())
    .build()
val api = retrofit.create(AppApi::class.java)

// ---------- ViewModel ----------
class AppViewModel : ViewModel() {
    private val _apps = MutableStateFlow<List<AppItem>>(emptyList())
    val apps: StateFlow<List<AppItem>> = _apps
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    init { fetchApps() }

    fun fetchApps() {
        viewModelScope.launch {
            try { _apps.value = api.getApps() }
            catch (e: Exception) { _error.value = "Failed: ${e.message}" }
        }
    }
}

// ---------- Navigation ----------
sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Apps : Screen("apps")
    object Games : Screen("games")
    object Search : Screen("search")
    object Detail : Screen("detail/{appId}") {
        fun createRoute(id: String) = "detail/$id"
    }
}

// ---------- Main Activity ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppStoreTheme {
                val nav = rememberNavController()
                Scaffold(bottomBar = { BottomNav(nav) }) { pad ->
                    NavHost(nav, startDestination = Screen.Home.route, Modifier.padding(pad)) {
                        composable(Screen.Home.route) { TodayScreen(nav) }
                        composable(Screen.Apps.route) { AppsScreen(nav) }
                        composable(Screen.Games.route) { GamesScreen(nav) }
                        composable(Screen.Search.route) { SearchScreen(nav) }
                        composable(Screen.Detail.route) {
                            val id = it.arguments?.getString("appId")
                            DetailScreen(id)
                        }
                    }
                }
            }
        }
    }
}

// ---------- Theme ----------
@Composable
fun AppStoreTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF007AFF),
            background = Color(0xFF1C1C1E).copy(alpha = 0.8f),
            surface = Color(0xFF2C2C2E).copy(alpha = 0.7f)
        ),
        content = content
    )
}

// ---------- Bottom Nav ----------
@Composable
fun BottomNav(nav: NavHostController) {
    NavigationBar(containerColor = Color(0xFF1C1C1E).copy(alpha = 0.95f), modifier = Modifier.blur(10.dp)) {
        val items = listOf(Screen.Home, Screen.Apps, Screen.Games, Screen.Search)
        items.forEach { screen ->
            NavigationBarItem(
                icon = { Icon(painterResource(id = when(screen){
                    Screen.Home -> android.R.drawable.ic_menu_today
                    Screen.Apps -> android.R.drawable.ic_menu_view
                    Screen.Games -> android.R.drawable.ic_menu_slideshow
                    else -> android.R.drawable.ic_menu_search
                }), contentDescription = null) },
                label = { Text(screen.route.capitalize()) },
                selected = false,
                onClick = { nav.navigate(screen.route) }
            )
        }
    }
}

// ---------- Card ----------
@Composable
fun AppCard(app: AppItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .shadow(8.dp, RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.2f))
            .blur(5.dp)
            .clickable(onClick = onClick)
            .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
            Image(
                painter = rememberAsyncImagePainter(app.icon),
                contentDescription = null,
                modifier = Modifier.size(64.dp).padding(end = 16.dp),
                contentScale = ContentScale.Crop
            )
            Column {
                Text(app.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text(app.developer, fontSize = 14.sp, color = Color.LightGray)
                Text("${app.rating} star", fontSize = 14.sp, color = Color.Yellow)
            }
        }
    }
}

// ---------- Screens ----------
@Composable fun TodayScreen(nav: NavHostController) { CommonList(nav, limit = 5) }
@Composable fun AppsScreen(nav: NavHostController) { CommonList(nav) }
@Composable fun GamesScreen(nav: NavHostController) { CommonList(nav) { it.category == "Games" } }

@Composable
fun CommonList(nav: NavHostController, limit: Int? = null, filter: (AppItem)->Boolean = {true}) {
    val vm: AppViewModel = viewModel()
    val apps by vm.apps.collectAsState()
    val err by vm.error.collectAsState()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text((when(this@CommonList){is TodayScreen->"Today";is AppsScreen->"Apps";else->"Games"}).uppercase(),
            fontSize = 32.sp, modifier = Modifier.padding(16.dp), color = Color.White)

        if (err != null) Text(err!!, color = Color.Red, modifier = Modifier.padding(16.dp))
        else if (apps.isEmpty()) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        else {
            val list = apps.filter(filter)
            LazyColumn {
                items(if(limit!=null) list.take(limit) else list) { app ->
                    AppCard(app) { nav.navigate(Screen.Detail.createRoute(app.id)) }
                }
            }
        }
    }
}

@Composable
fun SearchScreen(nav: NavHostController) {
    val vm: AppViewModel = viewModel()
    val apps by vm.apps.collectAsState()
    var query by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize()) {
        TextField(
            value = query, onValueChange = { query = it },
            label = { Text("Search") },
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        val filtered = apps.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.description.contains(query, ignoreCase = true)
        }
        LazyColumn {
            items(filtered) { app -> AppCard(app) { nav.navigate(Screen.Detail.createRoute(app.id)) } }
        }
    }
}

@Composable
fun DetailScreen(appId: String?) {
    val vm: AppViewModel = viewModel()
    val apps by vm.apps.collectAsState()
    val app = apps.find { it.id == appId }
    val ctx = LocalContext.current

    if (app == null) {
        Text("App not found", modifier = Modifier.fillMaxSize().wrapContentSize())
        return
    }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Image(
            painter = rememberAsyncImagePainter(app.icon),
            contentDescription = null,
            modifier = Modifier.size(128.dp).align(Alignment.CenterHorizontally),
            contentScale = ContentScale.Crop
        )
        Text(app.name, fontSize = 28.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        Text(app.description, fontSize = 16.sp)
        Text("Developer: ${app.developer}")
        Text("Rating: ${app.rating} star")
        Text("Price: ${app.price}")
        Spacer(Modifier.height(16.dp))
        Button(onClick = { Toast.makeText(ctx, "Downloading ${app.name}…", Toast.LENGTH_SHORT).show() }) {
            Text("GET")
        }
    }
}
